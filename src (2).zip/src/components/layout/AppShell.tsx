"use client";

import * as React from "react";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { RouteProgressBar } from "./RouteProgressBar";
import { VerifyEmailBanner } from "@/components/auth/VerifyEmailBanner";

export function AppShell({
  children, onSearch,
}: { children: React.ReactNode; onSearch?: (q: string) => void }) {
  const [mobileOpen, setMobileOpen] = React.useState(false);

  // Lets the guided tour open/close the mobile drawer (see components/tour/TourProvider).
  React.useEffect(() => {
    const onSidebar = (event: Event) => setMobileOpen((event as CustomEvent<"open" | "close">).detail === "open");
    window.addEventListener("sl:sidebar", onSidebar);
    return () => window.removeEventListener("sl:sidebar", onSidebar);
  }, []);

  return (
    // h-screen + overflow-hidden turns this into a fixed "app shell": the
    // sidebar and header stay in place, and only <main> scrolls. Previously
    // this was min-h-screen with no overflow control, so a tall page (a
    // playlist with hundreds of videos) scrolled the *whole* layout —
    // sidebar and header included — out of view.
    <div className="flex h-screen overflow-hidden">
      <RouteProgressBar />
      <React.Suspense fallback={null}>
        <Sidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      </React.Suspense>
      <div className="flex min-w-0 flex-1 flex-col">
        <Header onMenuClick={() => setMobileOpen(true)} onSearch={onSearch} />
        <VerifyEmailBanner />
        <main className="flex-1 overflow-y-auto overflow-x-hidden p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}
