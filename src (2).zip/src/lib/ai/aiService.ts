import { AiServiceError } from "./errors";
import { buildGoalSuggestionPrompt, buildQuizPrompt, buildStarterSummaryPrompt, languageInstruction } from "./prompts";
import { generateWithGemini } from "./providers/gemini";
import { generateWithOpenAi } from "./providers/openai";
import { generateWithAnthropic } from "./providers/anthropic";
import { generateWithOpenRouter } from "./providers/openrouter";
import { generateWithGroq } from "./providers/groq";
import { AI_OPTIONS } from "./generateOptions";
import type {
  AiConnectionCredentials,
  AiGenerateOptions,
  GoalSuggestion,
  GoalSuggestionInput,
  QuizQuestion,
  QuizVideoInput,
  VideoSummaryInput,
} from "./types";
import type { RoadmapLevel, RoadmapStep } from "@/types";
import { sanitizeRoadmapStepDetails, sanitizeRoadmapSteps } from "@/lib/roadmapUtils";

/**
 * Application-facing AI API. This is the ONLY module that video/summary
 * code (Phase 5) should import from src/lib/ai — never a provider adapter
 * directly, and never a Gemini SDK.
 *
 * Current architecture (see study-lamp-ai-roadmap.md, Phase 8):
 *
 *   AI Service -> provider adapter -> Gemini/OpenAI API
 *
 * That change should be internal to this file. The exported signature —
 * generateVideoSummary(connection, video) — is intended to stay stable
 * across that change; only what happens inside it should grow (e.g. trying
 * further connections on a transient AiServiceError instead of returning
 * after the first attempt).
 */
export function withResponseLanguage(prompt: string, language: "en" | "bn" = "en"): string {
  return `${prompt}\n\nResponse language: ${languageInstruction(language)}`;
}

/**
 * The ONE place a prompt is sent to a provider. It appends the response-language
 * instruction exactly once, so no feature adds its own language sentence, and
 * forwards generation options ({ maxOutputTokens, temperature, json }).
 */
export async function generateAiText(
  connection: AiConnectionCredentials,
  prompt: string,
  options?: AiGenerateOptions,
): Promise<string> {
  const localizedPrompt = withResponseLanguage(prompt, connection.language);

  switch (connection.provider) {
    case "gemini": return generateWithGemini(connection, localizedPrompt, options);
    case "openai": return generateWithOpenAi(connection, localizedPrompt, options);
    case "anthropic": return generateWithAnthropic(connection, localizedPrompt, options);
    case "openrouter": return generateWithOpenRouter(connection, localizedPrompt, options);
    case "groq": return generateWithGroq(connection, localizedPrompt, options);
    default: {
      const _exhaustive: never = connection.provider;
      throw new AiServiceError("unsupported_provider", `Provider "${_exhaustive}" is not supported yet.`);
    }
  }
}

export async function generateVideoSummary(
  connection: AiConnectionCredentials,
  video: VideoSummaryInput
): Promise<string> {
  const prompt = buildStarterSummaryPrompt(video);

  return generateAiText(connection, prompt, AI_OPTIONS.summary);
}

export async function generateDocumentPageExplanation(
  connection: AiConnectionCredentials,
  input: { title: string; pageNumber: number; pageText: string },
): Promise<string> {
  const prompt = `You are a patient study tutor. Explain the material from page ${input.pageNumber} of "${input.title}" in clear, accessible language.
Use the provided page text as the only factual source. Define important terms, connect the ideas, and include a short example only when it helps. If the text is fragmentary, say what can and cannot be inferred. Do not invent details from other pages.

Page text:
${input.pageText}`;

  return generateAiText(connection, prompt, AI_OPTIONS.summary);
}

export interface RoadmapPlan {
  basic: RoadmapStep[];
  intermediate: RoadmapStep[];
  advanced: RoadmapStep[];
}

function roadmapPrompt(categoryName: string): string {
  return `You are a curriculum designer for a personalized learning app. Generate a learning roadmap for the category "${categoryName}".
Return JSON only with this exact structure:
{
  "basic": [{ "title": "string", "description": "string", "order": 1 }, ...],
  "intermediate": [{ "title": "string", "description": "string", "order": 1 }, ...],
  "advanced": [{ "title": "string", "description": "string", "order": 1 }, ...]
}
Requirements:
- Each level must contain 3 to 6 steps.
- Keep the language clear and actionable.
- Use realistic learning milestones for the category.
- Keep descriptions concise but useful.
- JSON must valid and parseable.`;
}

export function buildRoadmapStepsPrompt(input: { categoryName: string; level: RoadmapLevel; subtopics: string[] }): string {
  const { categoryName, level, subtopics } = input;
  const focus = subtopics.length > 0 ? subtopics.join(", ") : "all core sub-skills of this topic";
  return `You are an expert curriculum designer creating a week-by-week study plan.
 
Topic: "${categoryName}"
Learner level: ${level}
Specific focus areas requested by the learner: ${focus}
 
Design a ${level}-level roadmap broken into WEEKS, not vague topic names. Use current, widely-accepted best practice for teaching this subject.
 
Rules:
- Return between 4 and 10 weeks for THIS level only — do not include other levels.
- Each week builds on the previous one and stays within scope for a "${level}" learner.
- Each week needs a short one-sentence "description" summarizing the week's goal.
- Each week also needs a "details" array of 3 to 5 short, concrete bullet points — specific actions, sub-topics, or exercises for that week (not restatements of the title). At least ONE bullet in every week must include a short worked example, prefixed with "e.g." (a real snippet, phrase, sentence, or scenario the learner can immediately try — not a placeholder).
- Stay strictly focused on: ${focus}.
- Return JSON only — no prose, no markdown fences — in this exact shape:
[
  {
    "week": 1,
    "title": "string",
    "description": "one-sentence summary of this week's goal",
    "details": [
      "concrete action or sub-topic for this week",
      "another concrete action, e.g. a short worked example here"
    ]
  }
]`;
}

function clarifyTopicPrompt(rawName: string): string {
  return `A learner typed "${rawName}" as something they want to learn.

If this term is short, ambiguous, or could mean several distinct learning topics (an abbreviation, a tool/language with several common learning angles, an overloaded word), propose 2 to 4 distinct, concrete interpretations.

Return JSON only, no prose:
{ "ambiguous": true, "options": [ { "label": "string", "description": "one sentence" } ] }
or, if the term is already a clear, specific learning topic:
{ "ambiguous": false }`;
}

export function parseRoadmapStepsFromText(raw: string): RoadmapStep[] {
  const text = (raw ?? "").trim();
  if (!text) throw new AiServiceError("invalid_request", "Invalid roadmap response.");
  const payloadText = extractJsonPayloadText(text, "array");

  let parsed: unknown;
  try {
    parsed = JSON.parse(payloadText);
  } catch {
    throw new AiServiceError("invalid_request", "Invalid roadmap response.");
  }
  if (!Array.isArray(parsed)) throw new AiServiceError("invalid_request", "Invalid roadmap response.");

  const steps = sanitizeRoadmapSteps(
    parsed.map((item, index) => {
      const s = item as Record<string, unknown>;
      const week = Number.isFinite(s.week) ? Number(s.week) : index + 1;
      return {
        title: String(s.title ?? "").trim(),
        description: String(s.description ?? "").trim(),
        details: sanitizeRoadmapStepDetails(s.details),
        order: week - 1,
        week,
      };
    })
  );

  if (steps.length === 0) throw new AiServiceError("invalid_request", "Invalid roadmap response.");
  return steps;
}

export async function generateRoadmapStepsForLevel(
  connection: AiConnectionCredentials,
  input: { categoryName: string; level: RoadmapLevel; subtopics: string[] }
): Promise<RoadmapStep[]> {
  const prompt = buildRoadmapStepsPrompt(input);
  const raw = await generateAiText(connection, prompt, AI_OPTIONS.roadmapSteps);
  return parseRoadmapStepsFromText(raw);
}

export interface TopicClarification {
  ambiguous: boolean;
  options?: { label: string; description: string }[];
}

export function parseTopicClarificationFromText(raw: string): TopicClarification {
  const text = (raw ?? "").trim();
  if (!text) return { ambiguous: false };
  try {
    const parsed = JSON.parse(extractJsonPayloadText(text, "object")) as Record<string, unknown>;
    if (parsed?.ambiguous !== true) return { ambiguous: false };
    const options = Array.isArray(parsed.options)
      ? (parsed.options as Record<string, unknown>[])
        .map((o) => ({ label: String(o.label ?? "").trim(), description: String(o.description ?? "").trim() }))
        .filter((o) => !!o.label)
      : [];
    return options.length > 0 ? { ambiguous: true, options } : { ambiguous: false };
  } catch {
    return { ambiguous: false };
  }
}

export async function generateTopicClarification(connection: AiConnectionCredentials, rawName: string): Promise<TopicClarification> {
  const prompt = clarifyTopicPrompt(rawName);
  const raw = await generateAiText(connection, prompt, AI_OPTIONS.jsonObject);
  return parseTopicClarificationFromText(raw);
}

// Same shape, but frames the question around a FOCUS the learner picked
// within a category, not the category name itself. "English" as a
// category is fine; "English" as a focus is not specific enough — it
// could mean Literature, Grammar, IELTS prep, or Spoken English.

function clarifyFocusPrompt(categoryName: string, focusText: string): string {
  return `A learner is studying "${categoryName}" and wrote this as their specific focus: "${focusText}".
 
  Focus terms can be broad enough to span several distinct learning paths within the same category (for example, within "English": Literature, Grammar/Language mechanics, IELTS/exam prep, and Spoken/conversational English are all different tracks with different content).
  
  If "${focusText}" is broad or could mean more than one distinct learning path within "${categoryName}", propose 2 to 4 more specific alternatives.
  
  Return JSON only, no prose:
  { "ambiguous": true, "options": [ { "label": "string", "description": "one sentence" } ] }
  or, if it is already specific enough:
  { "ambiguous": false }`;
}

function extractJsonPayloadText(raw: string, expectedRoot: "object" | "array"): string {
  const text = (raw ?? "").trim();
  if (!text) return "";

  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fenced && fenced[1]) {
    return fenced[1].trim();
  }

  if (expectedRoot === "object") {
    const objectStart = text.indexOf("{");
    const objectEnd = text.lastIndexOf("}");
    if (objectStart !== -1 && objectEnd > objectStart) {
      return text.slice(objectStart, objectEnd + 1).trim();
    }
  } else {
    const arrayStart = text.indexOf("[");
    const arrayEnd = text.lastIndexOf("]");
    if (arrayStart !== -1 && arrayEnd > arrayStart) {
      return text.slice(arrayStart, arrayEnd + 1).trim();
    }
  }

  return text;
}

export async function generateFocusClarification(
  connection: AiConnectionCredentials,
  categoryName: string,
  focusText: string
): Promise<TopicClarification> {
  const prompt = clarifyFocusPrompt(categoryName, focusText);
  const raw = await generateAiText(connection, prompt, AI_OPTIONS.jsonObject);
  return parseTopicClarificationFromText(raw);
}

export function parseRoadmapPlanFromText(raw: string): RoadmapPlan {
  const text = (raw ?? "").trim();
  if (!text) throw new AiServiceError("invalid_request", "Invalid roadmap response.");

  const payloadText = extractJsonPayloadText(text, "object");

  let parsed: unknown;
  try {
    parsed = JSON.parse(payloadText);
  } catch {
    throw new AiServiceError("invalid_request", "Invalid roadmap response.");
  }

  if (!parsed || typeof parsed !== "object") {
    throw new AiServiceError("invalid_request", "Invalid roadmap response.");
  }

  const record = parsed as Record<string, unknown>;
  const basic = sanitizeRoadmapSteps(Array.isArray(record.basic) ? (record.basic as Array<Partial<RoadmapStep> | null | undefined>) : []);
  const intermediate = sanitizeRoadmapSteps(Array.isArray(record.intermediate) ? (record.intermediate as Array<Partial<RoadmapStep> | null | undefined>) : []);
  const advanced = sanitizeRoadmapSteps(Array.isArray(record.advanced) ? (record.advanced as Array<Partial<RoadmapStep> | null | undefined>) : []);

  if (basic.length === 0 || intermediate.length === 0 || advanced.length === 0) {
    throw new AiServiceError("invalid_request", "Invalid roadmap response.");
  }

  return { basic, intermediate, advanced };
}

export async function generateRoadmapPlan(
  connection: AiConnectionCredentials,
  categoryName: string
): Promise<RoadmapPlan> {
  const prompt = roadmapPrompt(categoryName);

  const raw = await generateAiText(connection, prompt, AI_OPTIONS.jsonObject);

  return parseRoadmapPlanFromText(raw);
}

export function parseQuizQuestionsFromText(raw: string): QuizQuestion[] {
  const text = (raw ?? "").trim();
  if (!text) throw new AiServiceError("invalid_request", "Invalid quiz response.");

  const payloadText = extractJsonPayloadText(text, "array");

  let parsed: unknown;
  try {
    parsed = JSON.parse(payloadText);
  } catch {
    throw new AiServiceError("invalid_request", "Invalid quiz response.");
  }

  if (!Array.isArray(parsed)) {
    throw new AiServiceError("invalid_request", "Invalid quiz response.");
  }

  const questions: QuizQuestion[] = parsed.map((item, index) => {
    const q = item as Record<string, unknown>;
    const options = Array.isArray(q.options) ? q.options.map((option) => option as Record<string, unknown>) : [];

    const normalized = {
      id: typeof q.id === "string" ? q.id : `q${index + 1}`,
      prompt: typeof q.prompt === "string" ? q.prompt.trim() : "",
      options: options.map((option, optIndex) => ({
        id: typeof option.id === "string" ? option.id : `o${optIndex + 1}`,
        text: typeof option.text === "string" ? option.text.trim() : "",
      })),
      correctOptionId: typeof q.correctOptionId === "string" ? q.correctOptionId : "",
      explanation: typeof q.explanation === "string" ? q.explanation.trim() : "",
    };

    const optionIds = new Set(normalized.options.map((option) => option.id));
    const hasDuplicateOptionIds = optionIds.size !== normalized.options.length;
    const hasBlankOption = normalized.options.some((option) => !option.id || !option.text);
    if (!normalized.prompt || normalized.options.length < 2 || hasDuplicateOptionIds || hasBlankOption || !optionIds.has(normalized.correctOptionId) || !normalized.explanation) {
      throw new AiServiceError("invalid_request", "Invalid quiz response.");
    }

    return normalized;
  });

  return questions;
}

export async function generateVideoQuiz(
  connection: AiConnectionCredentials,
  video: QuizVideoInput
): Promise<QuizQuestion[]> {
  const prompt = buildQuizPrompt(video);

  const raw = await generateAiText(connection, prompt, AI_OPTIONS.jsonArray);

  return parseQuizQuestionsFromText(raw);
}

/** Parses and validates the model's raw text into GoalSuggestion[],
 *  mirroring parseQuizQuestionsFromText's tolerant-but-strict shape: accept
 *  a fenced ```json block or bare JSON, but throw AiServiceError("invalid_request")
 *  rather than silently returning malformed/empty drafts. */
export function parseGoalSuggestionsFromText(raw: string): GoalSuggestion[] {
  const text = (raw ?? "").trim();
  if (!text) throw new AiServiceError("invalid_request", "Invalid goal suggestion response.");

  const payloadText = extractJsonPayloadText(text, "array");

  let parsed: unknown;
  try {
    parsed = JSON.parse(payloadText);
  } catch {
    throw new AiServiceError("invalid_request", "Invalid goal suggestion response.");
  }

  if (!Array.isArray(parsed)) {
    throw new AiServiceError("invalid_request", "Invalid goal suggestion response.");
  }

  const suggestions: GoalSuggestion[] = parsed.slice(0, 4).map((item) => {
    const g = item as Record<string, unknown>;
    const title = typeof g.title === "string" ? g.title.trim() : "";
    const notes = typeof g.notes === "string" ? g.notes.trim() : "";
    const daysFromNow = Number.isFinite(g.daysFromNow) ? Number(g.daysFromNow) : NaN;

    if (!title || !Number.isFinite(daysFromNow)) {
      throw new AiServiceError("invalid_request", "Invalid goal suggestion response.");
    }

    return { title, notes, daysFromNow };
  });

  if (suggestions.length === 0) {
    throw new AiServiceError("invalid_request", "Invalid goal suggestion response.");
  }

  return suggestions;
}

/** Turns a roadmap's steps into 2-4 candidate Goal drafts (Phase E4). Never
 *  writes a Goal itself — the caller (POST /api/ai/goals/suggest and the
 *  roadmap page) is responsible for turning an accepted draft into a real
 *  Goal via the existing goal-creation code. */
export async function generateGoalSuggestions(
  connection: AiConnectionCredentials,
  input: GoalSuggestionInput
): Promise<GoalSuggestion[]> {
  const prompt = buildGoalSuggestionPrompt(input);

  const raw = await generateAiText(connection, prompt, AI_OPTIONS.jsonArray);

  return parseGoalSuggestionsFromText(raw);
}

export { AiServiceError } from "./errors";
export type { AiErrorCode } from "./errors";
export type {
  AiConnectionCredentials,
  AiGenerateOptions,
  AiLanguage,
  GoalSuggestion,
  GoalSuggestionInput,
  QuizQuestion,
  QuizVideoInput,
  VideoSummaryInput,
} from "./types";
