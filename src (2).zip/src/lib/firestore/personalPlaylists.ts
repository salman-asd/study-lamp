import {
  addDoc, collection, deleteDoc, doc, getCountFromServer, getDoc, getDocs, increment,
  limit, orderBy, query, serverTimestamp, Timestamp, updateDoc, where, writeBatch,
} from "@/lib/firestore/instrumented";
import { db } from "@/lib/firebase";
import { mapWithConcurrency } from "@/lib/allVideosUtils";
import { computePlaylistSummary, summaryNeedsWrite } from "@/lib/playlistSummary";
import type { PersonalPlaylist, PersonalPlaylistSortMode, PersonalPlaylistVisibility, PersonalVideo, PriorityLevel, VideoPlatform, WatchStatus } from "@/types";

/**
 * Personal playlists live under users/{ownerId}/personalPlaylists/{id} —
 * separate from the shared /playlists collection. `ownerId` is always
 * required explicitly (rather than assumed to be "the current user") so the
 * same functions can be reused by the admin UI when an admin is managing a
 * specific student's personal library (see firestore.rules: owner OR admin).
 */
const playlistsCol = (ownerId: string) => collection(db, "users", ownerId, "personalPlaylists");
const videosCol = (ownerId: string, playlistId: string) =>
  collection(db, "users", ownerId, "personalPlaylists", playlistId, "videos");

/** Flags a playlist's summary as out of date (cover/progress/next-video). Cheap single
 *  write; the detail page or the list page's bounded backfill recomputes it later. */
export async function markPlaylistSummaryStale(ownerId: string, playlistId: string) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId), { summaryStale: true }).catch(() => {});
}

/**
 * Recomputes and stores a playlist's summary from its videos. Writes only when
 * something actually changed (or the summary was missing/stale), and never bumps
 * `updatedAt` — this is bookkeeping, not an edit. Returns the summary now in
 * effect so callers can patch local state without re-reading.
 */
export async function recomputePlaylistSummary(
  ownerId: string,
  playlist: Pick<PersonalPlaylist, "id" | "sortOrder" | "summary" | "summaryStale">,
  videos: PersonalVideo[],
): Promise<PersonalPlaylist["summary"]> {
  const fresh = computePlaylistSummary(videos, playlist.sortOrder ?? []);
  if (!summaryNeedsWrite(playlist.summary, playlist.summaryStale, fresh)) return playlist.summary ?? null;

  const { lastWatchedAtMs, ...rest } = fresh;
  const lastWatchedAt = lastWatchedAtMs > 0 ? Timestamp.fromMillis(lastWatchedAtMs) : null;
  const summary = { ...rest, lastWatchedAt, computedAt: serverTimestamp() };
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlist.id), { summary, summaryStale: false });
  return { ...rest, lastWatchedAt, computedAt: Timestamp.now() };
}

export async function listPersonalPlaylists(ownerId: string): Promise<PersonalPlaylist[]> {
  const snap = await getDocs(query(playlistsCol(ownerId), limit(100)));
  return snap.docs.map((d) => ({ id: d.id, ownerId, ...d.data() }) as PersonalPlaylist);
}

export async function getPersonalPlaylist(ownerId: string, playlistId: string): Promise<PersonalPlaylist | null> {
  const snap = await getDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId));
  return snap.exists() ? ({ id: snap.id, ownerId, ...snap.data() } as PersonalPlaylist) : null;
}

export async function getOrCreateUnsortedPlaylist(ownerId: string): Promise<PersonalPlaylist> {
  const existing = await getDocs(query(playlistsCol(ownerId), where("isUnsorted", "==", true)));
  if (!existing.empty) {
    const playlist = existing.docs[0];
    return { id: playlist.id, ownerId, ...playlist.data() } as PersonalPlaylist;
  }

  const ref = await addDoc(playlistsCol(ownerId), {
    title: "Unsorted",
    description: "Videos saved without a playlist.",
    isUnsorted: true,
    visibility: "private" as PersonalPlaylistVisibility,
    sortMode: "custom" as PersonalPlaylistSortMode,
    sortOrder: [],
    videoCount: 0,
    totalDurationSeconds: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return {
    id: ref.id, ownerId, title: "Unsorted", description: "Videos saved without a playlist.",
    isUnsorted: true, visibility: "private", sortMode: "custom", sortOrder: [],
    videoCount: 0, totalDurationSeconds: 0, createdAt: null, updatedAt: null,
  };
}

export async function createPersonalPlaylist(
  ownerId: string,
  title: string,
  description = "",
  visibility: PersonalPlaylistVisibility = "private",
  categoryId: string | null = null,
  tagIds: string[] = [],
): Promise<string> {
  const ref = await addDoc(playlistsCol(ownerId), {
    title,
    description,
    visibility,
    categoryId,
    tagIds,
    sortMode: "custom" as PersonalPlaylistSortMode,
    sortOrder: [],
    videoCount: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

export async function renamePersonalPlaylist(
  ownerId: string,
  playlistId: string,
  title: string,
  description?: string,
  visibility?: PersonalPlaylistVisibility,
  categoryId?: string | null,
  tagIds?: string[],
) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId), {
    title,
    ...(description !== undefined ? { description } : {}),
    ...(visibility ? { visibility } : {}),
    ...(categoryId !== undefined ? { categoryId } : {}),
    ...(tagIds !== undefined ? { tagIds } : {}),
    updatedAt: serverTimestamp(),
  });
}

export async function setPersonalPlaylistSortMode(
  ownerId: string,
  playlistId: string,
  sortMode: PersonalPlaylistSortMode,
) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId), {
    sortMode,
    updatedAt: serverTimestamp(),
  });
}

/** Sets "advanced-keywords" sort mode together with the keyword list it
 *  should sort by, in one write, so the playlist never ends up saved in
 *  "advanced-keywords" mode without keywords to back it. */
export async function setPersonalPlaylistSortKeywords(
  ownerId: string,
  playlistId: string,
  sortKeywords: string[],
) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId), {
    sortMode: "advanced-keywords" as PersonalPlaylistSortMode,
    sortKeywords,
    updatedAt: serverTimestamp(),
  });
}

/** Overwrites (not increments) the playlist's stored total duration to
 *  match a freshly computed sum. `totalDurationSeconds` is normally kept
 *  in sync incrementally by the various add/remove/duration-backfill
 *  functions above, but that only covers changes made *after* this field
 *  existed — a playlist with videos/durations from before this feature
 *  would otherwise show a stale (0 or partial) total forever. The detail
 *  page calls this once after loading if the stored value doesn't match
 *  what it just computed client-side from the actual videos, which
 *  self-heals that gap without needing a one-time migration script. */
export async function syncPersonalPlaylistTotalDuration(ownerId: string, playlistId: string, seconds: number) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId), {
    totalDurationSeconds: seconds,
  });
}

/** Toggles whether finishing a video in this playlist auto-advances to the
 *  next one. Saves immediately (it's a settings switch, not a form field
 *  behind a Save button) — see the Autoplay control in the playlist header. */
export async function setPersonalPlaylistAutoPlay(ownerId: string, playlistId: string, autoPlay: boolean) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId), {
    autoPlay,
    updatedAt: serverTimestamp(),
  });
}

export async function deletePersonalPlaylist(ownerId: string, playlistId: string) {
  const vids = await getDocs(videosCol(ownerId, playlistId));
  const batch = writeBatch(db);
  vids.docs.forEach((d) => batch.delete(d.ref));
  batch.delete(doc(db, "users", ownerId, "personalPlaylists", playlistId));
  await batch.commit();
}

export async function listPersonalVideos(ownerId: string, playlistId: string): Promise<PersonalVideo[]> {
  const q = query(videosCol(ownerId, playlistId), orderBy("order", "asc"));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, playlistId, ownerId, ...d.data() }) as PersonalVideo);
}

export async function getPersonalVideo(ownerId: string, playlistId: string, videoId: string): Promise<PersonalVideo | null> {
  const snap = await getDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId));
  return snap.exists() ? ({ id: snap.id, playlistId, ownerId, ...snap.data() } as PersonalVideo) : null;
}

export async function addExistingVideoToPersonalPlaylist(
  ownerId: string,
  playlistId: string,
  video: {
    title: string;
    videoUrl: string;
    youtubeVideoId?: string | null;
    thumbnailUrl: string;
    durationSeconds?: number;
    description?: string | null;
    creator?: string | null;
    categoryId?: string | null;
    platform?: VideoPlatform;
  }
): Promise<boolean> {
  const duplicate = await findDuplicatePersonalVideoUrl(ownerId, playlistId, video.videoUrl);
  if (duplicate) return false;
  await addPersonalVideo(ownerId, playlistId, video);
  return true;
}

export async function bulkAddVideosToPersonalPlaylist(
  ownerId: string,
  playlistId: string,
  videoList: Array<{
    title: string;
    videoUrl: string;
    youtubeVideoId?: string | null;
    thumbnailUrl: string;
    durationSeconds?: number;
    description?: string | null;
    creator?: string | null;
    platform?: VideoPlatform;
  }>
): Promise<number> {
  if (videoList.length === 0) return 0;

  const existing = await listPersonalVideos(ownerId, playlistId);
  const existingUrls = new Set(existing.map((video) => video.videoUrl.trim().toLowerCase()));
  const uniqueVideos = videoList.filter((video) => !existingUrls.has(video.videoUrl.trim().toLowerCase()));
  if (uniqueVideos.length === 0) return 0;

  const playlistRef = doc(db, "users", ownerId, "personalPlaylists", playlistId);
  const playlistSnap = await getDoc(playlistRef);
  const currentSortOrder = (playlistSnap.exists() ? (playlistSnap.data().sortOrder as string[] | undefined) : []) || [];

  // A Firestore batch caps out at 500 writes. A large imported playlist
  // (a few hundred videos is common) plus the trailing playlist-doc update
  // could exceed that, so video writes are chunked defensively — each
  // chunk is its own batch, and the playlist doc (sortOrder/videoCount) is
  // only updated once, after every chunk has committed.
  const CHUNK_SIZE = 400;
  const allNewIds: string[] = [];
  for (let start = 0; start < uniqueVideos.length; start += CHUNK_SIZE) {
    const chunk = uniqueVideos.slice(start, start + CHUNK_SIZE);
    const batch = writeBatch(db);
    const refs = chunk.map(() => doc(videosCol(ownerId, playlistId)));
    refs.forEach((ref, i) => {
      batch.set(ref, {
        ...chunk[i],
        order: existing.length + start + i,
        status: "not_started" as WatchStatus,
        watchedPercentage: 0,
        currentPositionSeconds: 0,
        isFavorite: false,
        isWatchLater: false,
        priority: null,
        lastWatchedAt: null,
        completedAt: null,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    });
    await batch.commit();
    allNewIds.push(...refs.map((ref) => ref.id));
  }

  await updateDoc(playlistRef, {
    sortOrder: [...currentSortOrder, ...allNewIds],
    sortMode: "custom" as PersonalPlaylistSortMode,
    videoCount: increment(uniqueVideos.length), summaryStale: true,
    totalDurationSeconds: increment(uniqueVideos.reduce((sum, v) => sum + (v.durationSeconds || 0), 0)),
    updatedAt: serverTimestamp(),
  });

  return uniqueVideos.length;
}

export async function addPersonalVideo(
  ownerId: string,
  playlistId: string,
  data: {
    title: string;
    videoUrl: string;
    youtubeVideoId?: string | null;
    thumbnailUrl: string;
    durationSeconds?: number;
    description?: string | null;
    creator?: string | null;
    publishedAt?: string | null;
    categoryId?: string | null;
    tagIds?: string[];
    platform?: VideoPlatform;
  }
): Promise<string> {
  const existing = await getCountFromServer(videosCol(ownerId, playlistId));
  const ref = await addDoc(videosCol(ownerId, playlistId), {
    ...data,
    order: existing.data().count,
    status: "not_started" as WatchStatus,
    watchedPercentage: 0,
    currentPositionSeconds: 0,
    isFavorite: false,
    isWatchLater: false,
    priority: null,
    lastWatchedAt: null,
    completedAt: null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  const playlistRef = doc(db, "users", ownerId, "personalPlaylists", playlistId);
  const playlistSnap = await getDoc(playlistRef);
  const currentSortOrder = (playlistSnap.exists() ? (playlistSnap.data().sortOrder as string[] | undefined) : []) || [];

  await updateDoc(playlistRef, {
    sortOrder: [...currentSortOrder, ref.id],
    sortMode: "custom" as PersonalPlaylistSortMode,
    videoCount: increment(1), summaryStale: true,
    totalDurationSeconds: increment(data.durationSeconds || 0),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

export async function addStandaloneVideo(
  ownerId: string,
  videoData: Parameters<typeof addPersonalVideo>[2],
): Promise<string> {
  const unsorted = await getOrCreateUnsortedPlaylist(ownerId);
  return addPersonalVideo(ownerId, unsorted.id, videoData);
}

export async function movePersonalVideoToPlaylist(
  ownerId: string,
  sourcePlaylistId: string,
  targetPlaylistId: string,
  videoId: string,
): Promise<boolean> {
  if (sourcePlaylistId === targetPlaylistId) return false;
  const sourceVideoRef = doc(db, "users", ownerId, "personalPlaylists", sourcePlaylistId, "videos", videoId);
  const sourceVideo = await getDoc(sourceVideoRef);
  if (!sourceVideo.exists()) return false;
  const video = sourceVideo.data();
  if (await findDuplicatePersonalVideoUrl(ownerId, targetPlaylistId, video.videoUrl)) return false;

  const targetVideos = await getDocs(videosCol(ownerId, targetPlaylistId));
  const targetPlaylistRef = doc(db, "users", ownerId, "personalPlaylists", targetPlaylistId);
  const sourcePlaylistRef = doc(db, "users", ownerId, "personalPlaylists", sourcePlaylistId);
  const [targetPlaylist, sourcePlaylist] = await Promise.all([getDoc(targetPlaylistRef), getDoc(sourcePlaylistRef)]);
  const targetOrder = (targetPlaylist.data()?.sortOrder as string[] | undefined) || [];
  const sourceOrder = ((sourcePlaylist.data()?.sortOrder as string[] | undefined) || []).filter((id) => id !== videoId);
  const targetVideoRef = doc(videosCol(ownerId, targetPlaylistId));
  const batch = writeBatch(db);
  batch.set(targetVideoRef, { ...video, playlistId: targetPlaylistId, order: targetVideos.size, updatedAt: serverTimestamp() });
  batch.delete(sourceVideoRef);
  batch.update(targetPlaylistRef, { sortOrder: [...targetOrder, targetVideoRef.id], videoCount: increment(1), summaryStale: true, totalDurationSeconds: increment(video.durationSeconds || 0), updatedAt: serverTimestamp() });
  batch.update(sourcePlaylistRef, { sortOrder: sourceOrder, videoCount: increment(-1), summaryStale: true, totalDurationSeconds: increment(-(video.durationSeconds || 0)), updatedAt: serverTimestamp() });
  await batch.commit();
  return true;
}

export async function findDuplicatePersonalVideoUrl(ownerId: string, playlistId: string, candidateUrl: string): Promise<boolean> {
  const normalized = candidateUrl.trim();
  if (!normalized) return false;

  const canonicalCandidate = (() => {
    try {
      const parsed = new URL(normalized);
      return parsed.href;
    } catch {
      return normalized.toLowerCase();
    }
  })();
  const candidates = Array.from(new Set([normalized, canonicalCandidate]));
  const matches = await Promise.all(candidates.map((videoUrl) => getDocs(query(
    videosCol(ownerId, playlistId),
    where("videoUrl", "==", videoUrl),
  ))));
  return matches.some((snapshot) => !snapshot.empty);
}

export async function updatePersonalVideoMeta(
  ownerId: string, playlistId: string, videoId: string,
  data: Partial<Pick<PersonalVideo, "title" | "videoUrl" | "thumbnailUrl" | "durationSeconds" | "categoryId" | "tagIds">>
) {
  const videoRef = doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId);

  // Only touch the playlist's running total if duration is actually
  // changing — read the prior value first so we write a *delta*, not the
  // new value outright (increment() is atomic; a plain overwrite would
  // race with concurrent adds/removes to the same playlist doc).
  if (data.durationSeconds !== undefined) {
    const prevSnap = await getDoc(videoRef);
    const prevSeconds = prevSnap.exists() ? (prevSnap.data().durationSeconds || 0) : 0;
    const delta = (data.durationSeconds || 0) - prevSeconds;
    if (delta !== 0) {
      await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId), {
        totalDurationSeconds: increment(delta),
        updatedAt: serverTimestamp(),
      });
    }
  }

  await updateDoc(videoRef, {
    ...data, updatedAt: serverTimestamp(),
  });
}

/** Replaces only the stored thumbnail URL (used to self-heal expired Facebook
 *  thumbnails). Deliberately does NOT bump `updatedAt`: refreshing a picture
 *  isn't a content edit and shouldn't reorder "recently updated" views. */
export async function refreshPersonalVideoThumbnail(
  ownerId: string, playlistId: string, videoId: string, thumbnailUrl: string,
) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), {
    thumbnailUrl,
    thumbnailRefreshedAt: serverTimestamp(),
  });
}

/** Batched duration backfill for videos saved before duration lookups
 *  existed (or where the source never had it, e.g. oEmbed). Keyed by
 *  videoId -> seconds. Chunked defensively, same reasoning as
 *  bulkAddVideosToPersonalPlaylist. */
export async function bulkSetPersonalVideoDurations(
  ownerId: string,
  playlistId: string,
  durationsByVideoId: Record<string, number>
) {
  const entries = Object.entries(durationsByVideoId);
  if (entries.length === 0) return;

  const CHUNK_SIZE = 400;
  for (let start = 0; start < entries.length; start += CHUNK_SIZE) {
    const batch = writeBatch(db);
    entries.slice(start, start + CHUNK_SIZE).forEach(([videoId, seconds]) => {
      batch.update(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), {
        durationSeconds: seconds,
        updatedAt: serverTimestamp(),
      });
    });
    await batch.commit();
  }

  // These were all previously missing (falsy/0), so the delta is simply
  // the full sum of what was just backfilled — no prior value to subtract.
  const totalSeconds = entries.reduce((sum, [, seconds]) => sum + seconds, 0);
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId), {
    totalDurationSeconds: increment(totalSeconds),
    updatedAt: serverTimestamp(),
  });
}

export async function removePersonalVideo(ownerId: string, playlistId: string, videoId: string) {
  const videoRef = doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId);
  const videoSnap = await getDoc(videoRef);
  const removedSeconds = videoSnap.exists() ? (videoSnap.data().durationSeconds || 0) : 0;

  await deleteDoc(videoRef);

  const playlistRef = doc(db, "users", ownerId, "personalPlaylists", playlistId);
  const playlistSnap = await getDoc(playlistRef);
  const existingSortOrder = (playlistSnap.exists() ? (playlistSnap.data().sortOrder as string[] | undefined) : []) || [];

  await updateDoc(playlistRef, {
    sortOrder: existingSortOrder.filter((id) => id !== videoId),
    sortMode: "custom" as PersonalPlaylistSortMode,
    videoCount: increment(-1), summaryStale: true,
    totalDurationSeconds: increment(-removedSeconds),
    updatedAt: serverTimestamp(),
  });
}

export async function bulkUpdatePersonalVideos(
  ownerId: string,
  playlistId: string,
  videoIds: string[],
  patch: Record<string, any>
) {
  if (videoIds.length === 0) return;
  const batch = writeBatch(db);
  videoIds.forEach((videoId) => {
    batch.update(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), {
      ...patch,
      updatedAt: serverTimestamp(),
    });
  });
  await batch.commit();
}

export async function bulkRemovePersonalVideos(ownerId: string, playlistId: string, videoIds: string[]) {
  if (videoIds.length === 0) return;
  const playlistRef = doc(db, "users", ownerId, "personalPlaylists", playlistId);
  const playlistSnap = await getDoc(playlistRef);
  const existingSortOrder = (playlistSnap.exists() ? (playlistSnap.data().sortOrder as string[] | undefined) : []) || [];

  const videoSnaps = await Promise.all(
    videoIds.map((videoId) => getDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId)))
  );
  const removedSeconds = videoSnaps.reduce((sum, snap) => sum + (snap.exists() ? (snap.data().durationSeconds || 0) : 0), 0);

  const batch = writeBatch(db);

  videoIds.forEach((videoId) => {
    batch.delete(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId));
  });

  batch.update(playlistRef, {
    sortOrder: existingSortOrder.filter((id) => !videoIds.includes(id)),
    sortMode: "custom" as PersonalPlaylistSortMode,
    videoCount: increment(-videoIds.length), summaryStale: true,
    totalDurationSeconds: increment(-removedSeconds),
    updatedAt: serverTimestamp(),
  });

  await batch.commit();
}

export async function reorderPersonalVideos(ownerId: string, playlistId: string, orderedVideoIds: string[]) {
  const batch = writeBatch(db);
  orderedVideoIds.forEach((videoId, index) => {
    batch.update(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), {
      order: index, updatedAt: serverTimestamp(),
    });
  });
  batch.update(doc(db, "users", ownerId, "personalPlaylists", playlistId), {
    sortOrder: orderedVideoIds,
    sortMode: "custom" as PersonalPlaylistSortMode,
    updatedAt: serverTimestamp(),
  });
  await batch.commit();
}

export async function movePersonalVideo(ownerId: string, playlistId: string, videoId: string, direction: "up" | "down") {
  const videos = await listPersonalVideos(ownerId, playlistId);
  const index = videos.findIndex((video) => video.id === videoId);
  if (index === -1) return;

  const targetIndex = direction === "up" ? index - 1 : index + 1;
  if (targetIndex < 0 || targetIndex >= videos.length) return;

  const reordered = [...videos];
  const [moved] = reordered.splice(index, 1);
  reordered.splice(targetIndex, 0, moved);
  await reorderPersonalVideos(ownerId, playlistId, reordered.map((video) => video.id));
}

/** Progress/favorite/watchLater/priority live directly on the video doc
 *  since only the owner (or admin) ever reads/writes it — no separate
 *  "state" collection needed here, unlike shared-library videos. */
export async function savePersonalVideoProgress(
  ownerId: string, playlistId: string, videoId: string,
  currentPositionSeconds: number, watchedPercentage: number
) {
  const status: WatchStatus = watchedPercentage >= 100 ? "completed" : watchedPercentage > 0 ? "in_progress" : "not_started";
  const patch: any = {
    currentPositionSeconds,
    watchedPercentage: Math.min(100, Math.round(watchedPercentage)),
    status,
    lastWatchedAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  if (status === "completed") patch.completedAt = serverTimestamp();
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), patch);
  // Only completion changes what the Playlists page shows (progress + "Continue"), so
  // ordinary autosaves don't pay for a second write.
  if (status === "completed") await markPlaylistSummaryStale(ownerId, playlistId);
}

export async function setPersonalVideoWatched(ownerId: string, playlistId: string, videoId: string, watched: boolean) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), {
    status: watched ? "completed" : "not_started",
    watchedPercentage: watched ? 100 : 0,
    completedAt: watched ? serverTimestamp() : null,
    updatedAt: serverTimestamp(),
  });
  await markPlaylistSummaryStale(ownerId, playlistId);
}

export async function bulkSetPersonalVideosWatched(ownerId: string, playlistId: string, videoIds: string[], watched: boolean) {
  await bulkUpdatePersonalVideos(ownerId, playlistId, videoIds, {
    status: watched ? "completed" : "not_started",
    watchedPercentage: watched ? 100 : 0,
    completedAt: watched ? serverTimestamp() : null,
  });
  await markPlaylistSummaryStale(ownerId, playlistId);
}

export async function togglePersonalVideoFavorite(ownerId: string, playlistId: string, videoId: string, value: boolean) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), {
    isFavorite: value, updatedAt: serverTimestamp(),
  });
}

export async function bulkTogglePersonalVideoFavorite(ownerId: string, playlistId: string, videoIds: string[], value: boolean) {
  await bulkUpdatePersonalVideos(ownerId, playlistId, videoIds, { isFavorite: value });
}

export async function togglePersonalVideoWatchLater(ownerId: string, playlistId: string, videoId: string, value: boolean) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), {
    isWatchLater: value, watchLaterOrder: value ? Date.now() : null, updatedAt: serverTimestamp(),
  });
}

export async function bulkTogglePersonalVideoWatchLater(ownerId: string, playlistId: string, videoIds: string[], value: boolean) {
  await bulkUpdatePersonalVideos(ownerId, playlistId, videoIds, { isWatchLater: value });
}

export async function setPersonalVideoPriority(ownerId: string, playlistId: string, videoId: string, priority: PriorityLevel) {
  await updateDoc(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", videoId), {
    priority, priorityOrder: priority ? Date.now() : null, updatedAt: serverTimestamp(),
  });
}

/** Persist manual drag-and-drop order for a cross-playlist personal list
 *  (Watch Later / Priority). Each entry may belong to a different personal
 *  playlist, so — unlike reorderPersonalVideos — every write targets its
 *  own video doc individually rather than one shared playlist's sortOrder.
 *  `indices` lets a caller pass each item's position in a larger merged
 *  list (e.g. one that also mixes in shared-library videos) instead of
 *  renumbering from 0 — defaults to the array's own order when omitted. */
export async function reorderPersonalVideoList(
  ownerId: string,
  entries: { id: string; playlistId: string }[],
  field: "watchLaterOrder" | "priorityOrder",
  indices?: number[]
) {
  const batch = writeBatch(db);
  entries.forEach(({ id, playlistId }, i) => {
    const index = indices ? indices[i] : i;
    batch.update(doc(db, "users", ownerId, "personalPlaylists", playlistId, "videos", id), {
      [field]: index,
      updatedAt: serverTimestamp(),
    });
  });
  await batch.commit();
}

/** Aggregates every video across all of a user's personal playlists — used
 *  by the cross-cutting personal views (Watch Later, Favorites, Priority,
 *  Continue Watching, Dashboard) so that state set from within "My
 *  Playlists" (favorite / watch later / priority / watched) actually shows
 *  up on those pages instead of being invisible outside the single
 *  playlist it was set in. Mirrors useVideoLibrary's per-playlist fetch
 *  pattern for the shared library, kept simple over a collectionGroup
 *  query so no extra Firestore rules are needed. */
export async function listAllPersonalVideos(ownerId: string): Promise<(PersonalVideo & { playlistTitle: string })[]> {
  const playlists = await listPersonalPlaylists(ownerId);
  const results = await mapWithConcurrency(
    playlists,
    8,
    async (playlist) => {
      const vids = await listPersonalVideos(ownerId, playlist.id);
      return vids.map((video) => ({ ...video, playlistTitle: playlist.title }));
    },
  );
  return results.flat();
}

export async function bulkSetPersonalVideoPriority(ownerId: string, playlistId: string, videoIds: string[], priority: PriorityLevel) {
  await bulkUpdatePersonalVideos(ownerId, playlistId, videoIds, { priority });
}
