import { NextResponse } from "next/server";
import { withAuthedRoute } from "@/lib/server/routeHelpers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// HOTFIX D14 — disabled until roadmap step Z2 lands.
// The old handler wrote to Google BEFORE the confirmation gate and took the
// rows/heading from the request body, breaking Global Rules 13 and 15.
// See study-lamp-roadmap-v7.md, STEP Z2.
export const POST = withAuthedRoute(async () => {
  return NextResponse.json({ error: "Temporarily unavailable" }, { status: 503 });
}, { scope: "googleApply", preset: "googleSync", limit: 20, tooManyMessage: "Too many spreadsheet apply requests. Please slow down." });

